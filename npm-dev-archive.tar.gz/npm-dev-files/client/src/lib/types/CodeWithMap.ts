import { CodeNodeRange } from './CodeNodeRange';


export interface CodeWithMap {
  code: string;
  nodeMap: CodeNodeRange[];
}
