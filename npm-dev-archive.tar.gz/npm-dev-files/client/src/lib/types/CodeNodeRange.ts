// Типы для карты кода

export interface CodeNodeRange {
  nodeId: string;
  startLine: number;
  endLine: number;
}
