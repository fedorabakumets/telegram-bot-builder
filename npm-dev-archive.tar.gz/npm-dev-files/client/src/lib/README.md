# Библиотека Bot Generator

Эта библиотека содержит все компоненты для генерации Telegram ботов.

## Структура

### 📁 `bot-generator/`
Основная логика генератора ботов, организованная по модулям:
- `analyzers/` - анализаторы функциональности ботов
- `core/` - основные функции генерации
- `handlers/` - обработчики специальных действий
- `utils/` - утилиты форматирования и обработки

### 📁 `generators/`
Генераторы различных файлов проекта:
- `generateConfigYaml.ts` - генерация конфигурационных файлов
- `generateDockerfile.ts` - генерация Docker файлов
- `generatePythonCodeWithMap.ts` - генерация Python кода с картой
- `generateReadme.ts` - генерация README файлов
- `generateRequirementsTxt.ts` - генерация requirements.txt

### 📁 `parsers/`
Парсеры и обработчики кода:
- `parseCodeMap.ts` - парсинг карты кода
- `removeCodeMarkers.ts` - удаление маркеров из кода

### 📁 `validators/`
Валидаторы данных:
- `validateBotStructure.ts` - валидация структуры бота
- `validateCommand.ts` - валидация команд

### 📁 `types/`
Типы и интерфейсы:
- `CodeWithMap.ts` - тип для кода с картой
- `CodeNodeRange.ts` - тип для диапазонов узлов

## Использование

```typescript
// Импорт всей библиотеки
import * as lib from '@/lib';

// Импорт конкретных модулей
import { generateConfigYaml } from '@/lib/generators';
import { validateBotStructure } from '@/lib/validators';
import { CodeWithMap } from '@/lib/types';

// Импорт основного генератора
import { botGenerator } from '@/lib';
```

## Индексные файлы

Каждая папка содержит `index.ts` файл для удобного импорта всех экспортов модуля.