// Re-export all types from shared schema for compatibility
export * from '@shared/schema';